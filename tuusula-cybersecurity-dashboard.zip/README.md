# Tuusulan kunta - Kyberturvallisuuden Seurantakeskus

## 📋 Project Overview
Executive-level cybersecurity monitoring dashboard for Tuusulan kunta's Digitaalisaatio ja tietohallinto department.

## 🎯 Features
- Real-time NCSC-FI cybersecurity feeds
- Executive-friendly transparent white & blue interface  
- Municipal government styling with Tuusula branding
- Automated threat categorization and filtering
- Professional operations center appearance

## 🚀 Deployment
This dashboard is designed to be deployed to Azure App Service.

### Files:
- `index.html` - Main dashboard application
- `web.config` - Azure App Service configuration
- `README.md` - Project documentation

### Suggested Azure Settings:
```
App name: tuusula-cybersecurity-dashboard
Resource Group: rg-tuusula-cybersecurity
Runtime: .NET Core 3.1 (for static content)
Operating System: Windows
Region: West Europe
Pricing Tier: Free F1
```

## 🎨 Design Theme
- **Colors**: Transparent white backgrounds with Finnish blue accents
- **Typography**: Inter font family for professional readability
- **Style**: Clean, executive-level municipal government interface
- **Branding**: Stylized "T" logo representing Tuusula

## 🔐 Security Features
- CORS headers configured for API access
- RSS/XML content type support
- Error handling for feed failures
- Municipal-appropriate styling and branding

---
**Tuusulan kunta Digitaalisaatio ja tietohallinto**
