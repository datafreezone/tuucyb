# Tuusulan kunta - Kyberturvallisuuden Seurantakeskus

Executive-level cybersecurity monitoring dashboard for Tuusulan kunta's Digitaalisaatio ja tietohallinto department.

## Features
- Real-time NCSC-FI cybersecurity feeds
- Executive-friendly transparent white & blue interface  
- Municipal government styling with Tuusula branding
- Automated threat categorization and filtering
- Professional operations center appearance

## Design
- Transparent white backgrounds with Finnish blue accents
- Inter font family for professional readability
- Clean, executive-level municipal government interface
- Stylized "T" logo representing Tuusula

## Technical
- CORS headers configured for API access
- RSS/XML content type support
- Error handling for feed failures
- Azure App Service compatible

---
**Tuusulan kunta Digitaalisaatio ja tietohallinto**
 